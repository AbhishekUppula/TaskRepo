﻿using IronXL;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using ToleranceTask.Models;

namespace ToleranceTask.ViewModels
{
    public class ToleranceFilterModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public ObservableCollection<ToleranceName> Items { get; set; }

        public ObservableCollection<Status> StatusItems { get; set; }

        public ObservableCollection<DesignSolution> DSItems { get; set; }

        public ToleranceFilterModel()
        {
            LoadTolerancenames();
        }

        public void LoadTolerancenames()
        {
            string filePath = "ToleranceTaskDB/ToleranceDB.xlsx";

            Items = new ObservableCollection<ToleranceName>();

            WorkBook workBook = WorkBook.Load(filePath);
            WorkSheet workSheet = workBook.WorkSheets[1];

            List<string> lstdsNames = new List<string>();
            List<string> lstUniquedsNames = new List<string>();
            List<string> lstStatus = new List<string>();
            List<string> lstUniqueStatus = new List<string>();

            for (int i = 2;i<=51;i++)
            {
                IronXL.Cell Bcell = workSheet["B" + i].First();
                string ToleranceName = Bcell.StringValue;

                Items.Add(new ToleranceName { Name = ToleranceName });

                IronXL.Cell Ecell = workSheet["E" + i].First();
                string DSSolution = Ecell.StringValue;
                lstdsNames.Add(DSSolution);

                IronXL.Cell Gcell = workSheet["G" + i].First();
                string StatusNames = Gcell.StringValue;
                lstStatus.Add(StatusNames);
            }
            DSItems = new ObservableCollection<DesignSolution>();
            StatusItems = new ObservableCollection<Status>();

            lstUniquedsNames = lstdsNames.Distinct().ToList();
            lstUniqueStatus = lstStatus.Distinct().ToList();

            foreach (var item in lstUniquedsNames)
            {
                DSItems.Add(new DesignSolution() { Name = item });
            }
            foreach(var item in lstUniqueStatus)
            {
                StatusItems.Add(new Status() { Name = item });
            }

        }

        protected virtual void OnPropertyChanged(ToleranceName propertyName)
        {
            MessageBox.Show(propertyName.Name);
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName.Name));
        }

        private ToleranceName _selectedItem;
        public ToleranceName SelectedItem
        {
            get { return _selectedItem; }
            set
            {
                _selectedItem = value;
                OnPropertyChanged(SelectedItem);
            }
        }
        
        public string SelectedValuePath { get; set; }

    }
}
