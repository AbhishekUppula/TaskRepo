﻿using IronXL;
using OfficeOpenXml;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;
using ToleranceTask.Models;
using ToleranceTask.Views;
using static OfficeOpenXml.ExcelErrorValue;

namespace ToleranceTask.ViewModels
{
    public class MainViewModel: INotifyPropertyChanged
    {
        public ICommand OpenWindowCommand { get; }
        public ObservableCollection<DatabaseModel> Items { get; set; }
        private DatabaseModel _selectedItem;
        public ICommand LoadSelectedTOCommand { get; }


        public MainViewModel()
        {
            OpenWindowCommand = new RelayCommand(OpenWindow);
            LoadSelectedTOCommand = new RelayCommand(LoadSelectedTo);
            LoadExcelData();
        }

        private void OpenWindow()
        {
            var secondViewModel = new ToleranceViewModel();
            secondViewModel.ReceivedValue = SelectedItem;

            var newWindow = new ToleranceGridView();
            newWindow.DataContext = secondViewModel;
            newWindow.Show();
        }

        private void LoadSelectedTo()
        {
            var newWindow = new ToleranceView();
            newWindow.Show();
        }


        private void LoadExcelData()
        {
            // Replace with the path to your Excel file
            string filePath = "ToleranceTaskDB/ToleranceDB.xlsx";

            Items = new ObservableCollection<DatabaseModel>();

            WorkBook workBook = WorkBook.Load(filePath);
            WorkSheet workSheet = workBook.WorkSheets.First();

            foreach (var cell in workSheet["B2:B6"])
            {
                Items.Add(new DatabaseModel { DBName = cell.StringValue });
                if (cell.StringValue == "Training")
                {
                    SelectedItem = new DatabaseModel();
                    SelectedItem.DBName = cell.StringValue;
                    SelectedValuePath = "DBName";
                }
            }
        }

        // INotifyPropertyChanged implementation
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(DatabaseModel propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName.DBName));
        }

        public DatabaseModel SelectedItem
        {
            get { return _selectedItem; }
            set
            {
                _selectedItem = value;
                OnPropertyChanged(SelectedItem);
            }
        }

        public string SelectedValuePath { get; set; }
    }
}
