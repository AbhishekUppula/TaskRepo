﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToleranceTask.Models
{
  public class ToleranceName
    {
        public string Name { get; set; }
    }

    public class Status
    {
        public string Name { get; set; }
    }
    public class DesignSolution
    {
        public string Name { get; set; }
    }

}
